import csv
import tkinter as tk
from tkinter import messagebox
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB

# Load dataset
subjects = []
labels = []

with open("email_subject_dataset.csv", "r", encoding="utf-8") as file:
    reader = csv.reader(file)
    next(reader)  # skip header
    for row in reader:
        subjects.append(row[0].lower())
        labels.append(row[1])

# Vectorize text
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(subjects)

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, labels, test_size=0.2)

# Train model
model = MultinomialNB()
model.fit(X_train, y_train)

# Build GUI
def classify_subject():
    subject = entry.get().strip()
    if not subject:
        messagebox.showwarning("Input Error", "Please enter an email subject!")
        return
    vector = vectorizer.transform([subject.lower()])
    prediction = model.predict(vector)[0]
    result_label.config(text=f"Prediction: {prediction}")

# Tkinter window setup
root = tk.Tk()
root.title("Email Subject Classifier")
root.geometry("400x150")

tk.Label(root, text="Enter Email Subject:", font=("Arial", 12)).pack(pady=5)

entry = tk.Entry(root, font=("Arial", 12), width=40)
entry.pack(pady=5)

predict_btn = tk.Button(root, text="Predict", command=classify_subject, font=("Arial", 12))
predict_btn.pack(pady=5)

result_label = tk.Label(root, text="Prediction: ", font=("Arial", 14, "bold"))
result_label.pack(pady=10)

root.mainloop()
