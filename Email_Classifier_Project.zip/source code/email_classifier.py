import csv
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score

# Load dataset
subjects = []
labels = []

with open("email_subject_dataset.csv", "r", encoding="utf-8") as file:
    reader = csv.reader(file)
    next(reader)  # Skip header
    for row in reader:
        subjects.append(row[0].lower())
        labels.append(row[1])

# Vectorize the subject lines
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(subjects)

# Split into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, labels, test_size=0.2)

# Train the model
model = MultinomialNB()
model.fit(X_train, y_train)

# Test and show accuracy
predictions = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, predictions))

# Try predicting a new subject
test_subject = input("\nEnter an email subject to classify: ")
test_vector = vectorizer.transform([test_subject.lower()])
result = model.predict(test_vector)
print("Prediction:", result[0])
